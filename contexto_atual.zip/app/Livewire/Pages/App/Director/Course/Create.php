<?php

namespace App\Livewire\Pages\App\Director\Course;

use Livewire\Component;

class Create extends Component
{
    public function render()
    {
        return view('livewire.pages.app.director.course.create');
    }
}
