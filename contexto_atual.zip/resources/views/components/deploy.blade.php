@include('components.layouts.head.app.links')
@include('components.layouts.head.web.links')
@include('components.layouts.bottom.app-scripts')
@include('components.layouts.bottom.web-scripts')
