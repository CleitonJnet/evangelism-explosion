@include('components.layouts.head.app.meta')

<title>{{ $fullTitle ?? 'Evangelism Explosion' }}</title>

@include('components.layouts.head.favicon')

@include('components.layouts.head.app.links')
