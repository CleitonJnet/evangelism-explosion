<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

@vite(entrypoints: ['resources/css/tailwind.css', 'resources/css/app.css', 'resources/js/app.js'])
{{-- <link rel="stylesheet" href="{{ asset('build/assets/tailwind-CP098Ld4.css') }}">
<link rel="stylesheet" href="{{ asset('build/assets/app-BX5XfgaJ.css') }}"> --}}

@livewireStyles
@fluxAppearance
@stack('css')
