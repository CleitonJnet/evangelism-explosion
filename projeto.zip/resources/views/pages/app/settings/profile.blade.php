<x-layouts.app :title="__('Perfil do usuário')">
    <livewire:pages.app.settings.profile />
</x-layouts.app>
