<x-layouts.app :title="__('Programação do treinamento')">
    <livewire:pages.app.teacher.training.schedule :training="$training" />
</x-layouts.app>
