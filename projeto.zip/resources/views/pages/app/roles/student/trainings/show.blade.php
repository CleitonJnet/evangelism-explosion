<x-layouts.app :title="__('Treinamento')">
    <livewire:pages.app.student.training.show :training="$training" />
</x-layouts.app>
