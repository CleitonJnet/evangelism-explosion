<x-layouts.app :title="__('Treinamento')">
    <livewire:pages.app.student.training.index />
</x-layouts.app>
