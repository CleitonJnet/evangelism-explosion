<x-layouts.app :title="$title ?? null">
    {{ $slot }}
</x-layouts.app>
