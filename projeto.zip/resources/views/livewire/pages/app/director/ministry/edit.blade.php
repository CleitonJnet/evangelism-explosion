<div>
    {{-- Care about people's approval and you will be their prisoner. --}}
</div>
