<div>
    {{ $profile->name }}
</div>
