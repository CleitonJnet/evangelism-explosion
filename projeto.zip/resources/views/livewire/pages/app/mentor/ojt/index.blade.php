<div class="space-y-6">
    <section class="rounded-2xl border border-[color:var(--ee-app-border)] bg-white p-6">
        <flux:heading size="sm" level="2">{{ __('My OJT') }}</flux:heading>
        <flux:text class="text-sm text-[color:var(--ee-app-muted)]">
            {{ __('Review your assigned OJT sessions and submit reports.') }}
        </flux:text>
    </section>
</div>
