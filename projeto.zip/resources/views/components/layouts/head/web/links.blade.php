<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

{{-- @vite(['resources/css/tailwind.css', 'resources/css/styles.css', 'resources/js/javascript.js']) --}}
<link rel="stylesheet" href="{{ asset('build/assets/tailwind-bbjlLOFT.css') }}">
<link rel="stylesheet" href="{{ asset('build/assets/styles-Bvhe80wL.css') }}">

@stack('css')
@livewireStyles
