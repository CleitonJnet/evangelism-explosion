<script type="module" src="{{ asset('build/assets/javascript-sDoQMdOR.js') }}"></script>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

@livewireScripts
@stack('js')
