<x-app.layouts.auth.simple :title="$title ?? null">
    {{ $slot }}
</x-app.layouts.auth.simple>
