{{-- Linha temática --}}
<div {{ $attributes->merge(['class' => 'h-0.5 w-full mx-auto']) }}
    style="border-radius: 100%; background: linear-gradient(135deg, #c7a8401a, #c7a8408c, #c7a8401a);">
</div>
