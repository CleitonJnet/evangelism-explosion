<?php

namespace App\Livewire\Pages\App\Director\Profile;

use Livewire\Component;

class Create extends Component
{
    public function render()
    {
        return view('livewire.pages.app.director.profile.create');
    }
}
